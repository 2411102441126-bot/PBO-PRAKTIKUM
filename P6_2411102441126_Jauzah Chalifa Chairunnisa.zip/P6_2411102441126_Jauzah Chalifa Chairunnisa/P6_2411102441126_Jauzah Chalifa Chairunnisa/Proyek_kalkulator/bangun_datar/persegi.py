import math

class Persegi:
    def __init__(self, sisi):
        self.sisi = sisi
    def hitung_luas(self):
        return self.sisi ** 2